package com.example.screentransition;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    
    


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    @Override
    public boolean onTouchEvent(MotionEvent event) {
    	
    	Intent i = new Intent(this, LoadedActivity.class);
    	startActivity(i);
    	
    	overridePendingTransition(R.drawable.animacao, R.drawable.animacao_2);
    	
    	// TODO Auto-generated method stub
    	return super.onTouchEvent(event);
    }
    
}
